package org.example.data;

import io.restassured.response.Response;

public class SharedTestData {
    private static Response response;
    private String responseBody;


    public static Response getResponse() {
        return response;
    }

    public static void setResponse(Response response) {
        this.response = response;
    }

    public String getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(String responseBody) {
        this.responseBody = responseBody;
    }


}
