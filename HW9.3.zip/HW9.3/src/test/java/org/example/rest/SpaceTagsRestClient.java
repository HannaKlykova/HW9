package org.example.rest;

import io.restassured.RestAssured;
import io.restassured.response.Response;



public class SpaceTagsRestClient extends BaseRestClient {
    String space_id = "90121479515";
    String spaceTagsUrl = "/space/" + space_id + "/tag";

    public SpaceTagsRestClient() {
        setupRestAssured();
    }

    public void setupRestAssured() {
        RestAssured.baseURI = "https://api.clickup.com/api/v2";
    }

    public Response getSpaceTags() {
        String space_id = "90121479515";
        return RestAssured.given()
                .when()
                .get("/space/" + space_id + "/tag");
    }
}
