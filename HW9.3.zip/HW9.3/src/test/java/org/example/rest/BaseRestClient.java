package org.example.rest;

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.serenitybdd.rest.SerenityRest;

abstract class BaseRestClient {
    public String token = "pk_2144452523_XWBOQCMLNN5HVAAN3IWLU7SJW1I2YGJF";
    public String baseUrl = "https://api.clickup.com/api/v2";

    protected RequestSpecification requestSpec;

    public void setupRestAssured() {

        this.requestSpec = SerenityRest.given()
                .baseUri(this.baseUrl)
                .header ("Authorization", token)
                .contentType(ContentType.JSON);
    }

    public Response getSpaceTags() {
        return null;
    }
}
