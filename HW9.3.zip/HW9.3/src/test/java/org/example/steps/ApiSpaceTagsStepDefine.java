package org.example.steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONArray;
import org.json.JSONObject;
//import okhttp3.Response;

public class ApiSpaceTagsStepDefine {

    String token = "pk_2144452523_XWBOQCMLNN5HVAAN3IWLU7SJW1I2YGJF";
    String baseUrl = "https://api.clickup.com/api/v2";
    String space_id = "90121479515";

    @Given("Sent request to Get Space Tags")
    public void getSpaceTags() {
        RestAssured.baseURI = baseUrl;
        RestAssured.given()
                .header("Authorization", token)
                .header("Content-Type", "application/json")
                .when()
                .get("/space/"+space_id+"/tag")
                .then()
                .statusCode(200)
                .extract().response();

    }

    @Given("Sent request to Get Spase Tags and get Space Tag id")
    public void getSpaceTagsIdFromResponse() {
        RequestSpecification response = RestAssured.given();
        RestAssured.baseURI = baseUrl;
        RestAssured.given()
                .header("Authorization", token)
                .header("Content-Type", "application/json")
                .when()
                .get("/space/" + space_id + "/tag")
                .then()
                .statusCode(200)
                .extract().response()
                .body()
                .asString();
        JSONObject obj = new JSONObject(response);
        JSONArray spaceTagsArray = obj.getJSONArray("spaceTags");
        JSONObject spaceTags = spaceTagsArray.getJSONObject(0);
        String id = spaceTags.getString ("id");
        System.out.println(id);

    }

    @When("Sent request to get all space tags")
    public void sentRequestToGetAllSpaceTags() {
    }
}
