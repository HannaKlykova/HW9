package org.example.steps;

import io.cucumber.java.en.Then;
import org.example.data.SharedTestData;

public class ResponseSteps extends BaseSteps {

    @Then("Check that status code is 200")
    public void checkStatus(){
        SharedTestData.getResponse().then().statusCode(200);
    }
}
