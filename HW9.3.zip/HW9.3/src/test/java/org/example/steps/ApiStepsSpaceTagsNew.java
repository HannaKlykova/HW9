package org.example.steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import org.example.data.SharedTestData;

public class ApiStepsSpaceTagsNew extends BaseSteps {

    Response response;

    @Given("Set request to get Spase Tags")
    public void getAllSpaceTags() {
        Response response = spaceTagsRestClient.getSpaceTags();
        SharedTestData.setResponse(response);
    }



}