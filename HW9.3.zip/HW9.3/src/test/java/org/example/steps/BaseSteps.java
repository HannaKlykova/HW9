package org.example.steps;

import org.example.data.SharedTestData;
import org.example.rest.SpaceTagsRestClient;


public class BaseSteps {
    protected SpaceTagsRestClient spaceTagsRestClient = new SpaceTagsRestClient();



}
