package org.example.app;

public class Calculator {
    public int add(int a, int b) {
        return a + b;
    }
}